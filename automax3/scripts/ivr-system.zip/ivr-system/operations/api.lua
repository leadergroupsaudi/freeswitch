--------------------------------------------------------------------------------
-- API Operations Module
--
-- Handles all API integration related operations including:
-- - Operation 111: API call (GET/POST with various content types)
-- - Operation 112: Simple API POST call
--
-- These operations interact with external web services to fetch data,
-- authenticate, create incidents, etc.
--
-- Usage:
--   Called automatically by the operation dispatcher
--   local api_ops = require "operations.api"
--   api_ops.execute(111, node_data)
--
-- Author: IVR System Team
-- Version: 2.0.0
--------------------------------------------------------------------------------

local M = {}

-- Load dependencies
local session_manager = require "core.session_manager"
local call_flow = require "core.call_flow"
local config = require "config"
local logging = require "utils.logging"
local string_utils = require "utils.string_utils"
local json_utils = require "utils.json_utils"

-- Module logger
local logger = logging.get_logger("operations.api")

--------------------------------------------------------------------------------
-- Execute API Operation
--
-- Main entry point for all API operations. Routes to specific handlers
-- based on operation code.
--
-- @param operation_code number - The operation code (111, 112)
-- @param node_data table - The IVR node configuration data
-- @return void
--------------------------------------------------------------------------------
function M.execute(operation_code, node_data)
    logger:info(string.format(
        "Executing API operation %d for node %d",
        operation_code, node_data.NodeId
    ))

    -- Route to appropriate handler
    if operation_code == 111 then
        M.api_call(node_data)
    elseif operation_code == 112 then
        M.api_post(node_data)
    else
        error(string.format("Unknown API operation code: %d", operation_code))
    end
end

--------------------------------------------------------------------------------
-- Helper: URL encode a string
--
-- @param str string - String to encode
-- @return string - URL encoded string
--------------------------------------------------------------------------------
local function urlencode(str)
    if str then
        str = string.gsub(str, "\n", "\r\n")
        str = string.gsub(str, "([^%w _%%%-%.~])", function(c)
            return string.format("%%%02X", string.byte(c))
        end)
        str = string.gsub(str, " ", "+")
    end
    return str
end

--------------------------------------------------------------------------------
-- Helper: URL encode a table
--
-- @param tbl table - Table of key-value pairs
-- @return string - URL encoded string
--------------------------------------------------------------------------------
local function urlencode_table(tbl)
    local result = {}
    for k, v in pairs(tbl) do
        table.insert(result, urlencode(k) .. "=" .. urlencode(tostring(v)))
    end
    return table.concat(result, "&")
end

--------------------------------------------------------------------------------
-- Helper: Convert table to values format for API
--
-- Transforms a Lua table into the specific JSON format expected by some APIs.
--
-- @param tbl table - Table to convert
-- @return table - Converted table with values array
--------------------------------------------------------------------------------
local function convert_to_values_format(tbl)
    local values_array = {}
    for key, value in pairs(tbl) do
        table.insert(values_array, {
            name = key,
            value = type(value) == "table" and json_utils.encode(value) or tostring(value)
        })
    end
    return { values = values_array }
end

--------------------------------------------------------------------------------
-- Helper: Replace placeholder in URL
--
-- @param url string - URL with placeholder
-- @param field_name string - Placeholder name (without braces)
-- @param replacement string - Replacement value
-- @return string - URL with placeholder replaced
--------------------------------------------------------------------------------
local function replace_placeholder(url, field_name, replacement)
    return url:gsub(field_name, replacement or "")
end

--------------------------------------------------------------------------------
-- Helper: Construct API call
--
-- Builds a curl command based on API configuration.
--
-- @param method_type string - HTTP method (GET, POST, etc.)
-- @param content_type string - Content type
-- @param service_url string - Base URL
-- @param api_input_data table - Input configuration
-- @return string - Constructed curl command
--------------------------------------------------------------------------------
local function construct_api(method_type, content_type, service_url, api_input_data)
    local session = session_manager.get_freeswitch_session()
    local payload = {}
    local headers = ""
    local form_data = ""
    local binary_data = ""

    logger:debug("Constructing API call")

    local input_array = api_input_data.headers or api_input_data.values or api_input_data

    for _, item in ipairs(input_array) do
        local input_type = item.InputType

        if input_type == "U" then
            -- URL parameter
            local input_value
            if item.InputValueType == "D" or item.InputValueType == "E" then
                input_value = session:getVariable(item.InputValue)
                service_url = replace_placeholder(service_url, '{' .. item.FieldName .. '}', input_value)
            elseif item.InputValueType == "S" then
                service_url = replace_placeholder(service_url, '{' .. item.FieldName .. '}', item.InputValue)
            end

        elseif input_type == "R" then
            -- Request body parameter
            local key = item.FieldName or item.name
            local val

            if item.InputValueType == "D" or item.InputValueType == "E" then
                local raw_input = item.InputValue or item.value
                local variable_name = tostring(raw_input):match("{{(.-)}}")

                if variable_name then
                    val = session:getVariable(variable_name)
                    if val then
                        val = tostring(val):gsub('^"(.*)"$', '%1')
                        val = tostring(raw_input):gsub("{{" .. variable_name .. "}}", val)
                    end
                else
                    val = session:getVariable(item.InputValue)
                end
            else
                val = item.value or item.InputValue
                if val then
                    if key == "Map" then
                        payload[key] = { coordinates = {0.0, 0.0} }
                    else
                        val = tostring(val):gsub('^"(.*)"$', '%1')
                        payload[key] = val
                    end
                end
            end

            if key and val and key ~= "Map" then
                payload[key] = val
            end

        elseif input_type == "B" then
            -- Binary data
            local input_value
            if item.InputValueType == "D" or item.InputValueType == "E" then
                input_value = session:getVariable(item.InputValue)
            else
                input_value = item.InputValue
            end
            binary_data = binary_data .. " --data-binary @" .. input_value

        elseif input_type == "F" then
            -- Form data
            local input_value
            if item.InputValueType == "D" or item.InputValueType == "E" then
                input_value = session:getVariable(item.InputValue)
            elseif item.InputValueType == "S" then
                input_value = item.InputValue
            end

            if input_value and string.find(input_value, "%.wav$") then
                form_data = form_data .. " -F " .. item.FieldName .. "=@" .. input_value
            else
                form_data = form_data .. " -F " .. item.FieldName .. "=" .. (input_value or "")
            end

        elseif input_type == "H" then
            -- Header
            local field_name = item.FieldName or item.name

            if item.InputValueType == "D" or item.InputValueType == "E" then
                local input_value = item.InputValue or item.value
                local start_pos, finish_pos = string.find(input_value, "{(.-)}")

                if start_pos and finish_pos then
                    local expression = string.sub(input_value, start_pos + 1, finish_pos - 1)
                    local updated_value = session:getVariable(expression)
                    input_value = string.gsub(input_value, "{" .. expression .. "}", updated_value or "")
                    headers = headers .. field_name .. ": " .. input_value
                else
                    local dynamic_value = session:getVariable(item.InputValue)
                    headers = headers .. item.FieldName .. ": " .. (dynamic_value or "")
                end
            elseif item.InputValueType == "S" then
                headers = headers .. item.FieldName .. ": " .. item.InputValue
            end
        end
    end

    -- Build final API command
    logger:debug("Service URL: " .. service_url)
    local final_api = service_url .. " -s -w '+%{http_code}' "

    if content_type == "multipart/form-data" then
        headers = string.gsub(headers, '"', '')
        final_api = "curl -s -w '+%{http_code}' -X " .. method_type ..
                   " -H '" .. headers .. "' " .. form_data .. " " .. final_api

    elseif content_type == "audio/wav" then
        headers = string.gsub(headers, '"', '')
        final_api = "curl -s -w '+%{http_code}' -X " .. method_type ..
                   " -H '" .. headers .. "' -H 'Content-Type: " .. content_type .. "' " ..
                   binary_data .. " " .. final_api

    else
        if content_type then
            final_api = final_api .. " -H \"Content-Type: " .. content_type .. "\""
        end

        if next(payload) ~= nil then
            local encoded_payload

            if content_type == "application/x-www-form-urlencoded" then
                encoded_payload = urlencode_table(payload)
            elseif content_type == "application/json" then
                local classification_value = session:getVariable("ClassificationIdEn") or
                                            session:getVariable("ClassificationIdAr")
                if classification_value then
                    payload["Classification"] = classification_value
                end

                local converted = convert_to_values_format(payload)
                encoded_payload = json_utils.encode(converted)
            else
                encoded_payload = json_utils.encode(payload)
            end

            encoded_payload = encoded_payload:gsub("\n", "")
            final_api = final_api .. " -X " .. method_type .. " -d '" .. encoded_payload .. "'"
        end

        if #headers > 0 then
            headers = string.gsub(headers, '"', '')
            final_api = final_api .. " -H \"" .. headers .. "\""
        end
    end

    logger:debug("Final API: " .. final_api)
    return final_api
end

--------------------------------------------------------------------------------
-- Helper: Execute command and return result
--
-- @param command string - Command to execute
-- @return string - Command output
--------------------------------------------------------------------------------
local function execute_command(command)
    local handle = io.popen(command)
    local result = handle:read("*a")
    handle:close()
    return result
end

--------------------------------------------------------------------------------
-- Operation 111: API Call
--
-- Makes an API call based on configuration. Supports various content types
-- and handles response parsing.
--
-- Node Data Requirements:
-- - APIId: ID of the API configuration to use
--
-- @param node_data table - The IVR node configuration data
-- @return void
--------------------------------------------------------------------------------
function M.api_call(node_data)
    logger:info(string.format(
        "Operation 111: API call for node %d",
        node_data.NodeId
    ))

    local session = session_manager.get_freeswitch_session()

    if not session or not session:ready() then
        logger:error("Session is not ready")
        return
    end

    local api_id = node_data.APIId
    logger:info("API ID: " .. tostring(api_id))

    -- Get API configuration
    local web_api_data = config.get_webapi_endpoints()

    if not web_api_data then
        logger:error("Web API configuration not found")
        call_flow.find_child_node_with_dtmf_input("F", node_data)
        return
    end

    local method_type, content_type, service_url, api_input_data, api_output

    for _, api in pairs(web_api_data) do
        if api.apiId == api_id then
            method_type = api.methodType
            content_type = api.inputMediaType
            service_url = api.serviceURL

            if type(api.apiInput) == "string" then
                api_input_data = json_utils.decode(api.apiInput)
            else
                api_input_data = api.apiInput
            end

            api_output = api.apiOutput
            break
        end
    end

    if not service_url then
        logger:error("API configuration not found for ID: " .. tostring(api_id))
        call_flow.find_child_node_with_dtmf_input("F", node_data)
        return
    end

    logger:info(string.format(
        "API config - Method: %s, ContentType: %s, URL: %s",
        method_type, content_type, service_url
    ))

    -- Construct and execute API call
    local final_api = construct_api(method_type, content_type, service_url, api_input_data)
    logger:debug("Final API command: " .. final_api)

    local input_keys = "F"

    if content_type == "application/json" then
        local curl_cmd = "curl " .. final_api
        local api_response = execute_command(curl_cmd)

        logger:debug("API response: " .. tostring(api_response))

        -- Parse response code
        local response_code = tonumber(api_response:match("%+(%d+)$"))
        local response_body = api_response:gsub("%+%d+$", "")

        logger:info("HTTP response code: " .. tostring(response_code))

        if response_code and response_code >= 200 and response_code < 300 then
            local success, decoded = pcall(json_utils.decode, response_body)

            if success and decoded then
                -- Check for recordID in response
                if decoded.response and decoded.response.recordID then
                    local record_id = decoded.response.recordID
                    session:setVariable("incident_no_reponse", record_id)
                    logger:info("Set incident_no_reponse = " .. record_id)
                end

                input_keys = "S"
            else
                logger:warning("Failed to decode JSON response")
            end
        end

    else
        -- Handle non-JSON content types (OAuth, etc.)
        local url = final_api:match("^(https://%S+)")
        local headers_list = {}

        for h in final_api:gmatch('%-H%s+"[^"]+"') do
            table.insert(headers_list, h)
        end

        local data = final_api:match('%-d%s*[\'"]([^\'"]+)[\'"]')

        local curl_cmd = 'curl -s -k -X POST '
        if data then
            curl_cmd = curl_cmd .. '-d "' .. data .. '" '
        end
        for _, h in ipairs(headers_list) do
            curl_cmd = curl_cmd .. h .. ' '
        end
        curl_cmd = curl_cmd .. (url or service_url)

        logger:debug("Formatted curl: " .. curl_cmd)

        local response = execute_command(curl_cmd)
        logger:debug("Response: " .. tostring(response))

        -- Parse response
        local body, status_code = response:match("^(.*)\n(%d%d%d)$")

        if not body then
            body = response
            status_code = 200
        end

        if body then
            body = body:gsub("^%s+", ""):gsub("%s+$", "")
        end
        status_code = tonumber(status_code)

        if status_code and status_code >= 200 and status_code < 300 then
            -- Process API output mapping
            if api_output and #api_output > 2 then
                local output_config = json_utils.decode(api_output)
                local decoded_response = json_utils.decode(body)

                if decoded_response and output_config then
                    for _, key in ipairs(output_config) do
                        if key.ParentResultId == nil then
                            local field_name = key.ResultFieldName

                            -- Handle token field name mapping
                            if field_name == "token" then
                                field_name = "access_token"
                            end

                            local value = decoded_response[field_name]
                            if value then
                                session:setVariable(key.ResultFieldTag, json_utils.encode(value))
                                logger:debug(string.format(
                                    "Set variable %s = %s",
                                    key.ResultFieldTag, json_utils.encode(value)
                                ))
                            end
                        end
                    end

                    -- Process parent-child relationships
                    for _, key in ipairs(output_config) do
                        if key.ParentResultId ~= nil then
                            local parent_result = json_utils.decode(
                                session:getVariable(key.ParentResultId)
                            )
                            if parent_result then
                                session:setVariable(
                                    key.ResultFieldTag,
                                    parent_result[key.ResultFieldName]
                                )
                            end
                        end
                    end
                end
            end

            input_keys = "S"
        end
    end

    call_flow.find_child_node_with_dtmf_input(input_keys, node_data)
end

--------------------------------------------------------------------------------
-- Operation 112: Simple API POST
--
-- Makes a simple API POST call using FreeSWITCH's built-in curl module.
--
-- Node Data Requirements:
-- - APIId: ID of the API configuration to use
--
-- @param node_data table - The IVR node configuration data
-- @return void
--------------------------------------------------------------------------------
function M.api_post(node_data)
    logger:info(string.format(
        "Operation 112: API POST for node %d",
        node_data.NodeId
    ))

    local session = session_manager.get_freeswitch_session()

    if not session or not session:ready() then
        logger:error("Session is not ready")
        return
    end

    local api_id = node_data.APIId

    -- Get API configuration
    local web_api_data = config.get_webapi_endpoints()

    if not web_api_data then
        logger:error("Web API configuration not found")
        call_flow.find_child_node_with_dtmf_input("F", node_data)
        return
    end

    local method_type, content_type, service_url, api_input_data

    for _, api in pairs(web_api_data) do
        if api.apiId == api_id then
            method_type = api.methodType
            content_type = api.inputMediaType
            service_url = api.serviceURL
            api_input_data = json_utils.decode(api.apiInput)
            break
        end
    end

    if not service_url then
        logger:error("API configuration not found for ID: " .. tostring(api_id))
        call_flow.find_child_node_with_dtmf_input("F", node_data)
        return
    end

    -- Construct and execute API call
    local final_api = construct_api(method_type, content_type, service_url, api_input_data)
    logger:debug("Final API: " .. final_api)

    -- Use FreeSWITCH curl module
    session:execute("curl", final_api)

    local curl_response_code = tonumber(session:getVariable("curl_response_code"))
    local curl_response = session:getVariable("curl_response_data")

    logger:info("Curl response code: " .. tostring(curl_response_code))

    if curl_response then
        logger:debug("Curl response data: " .. curl_response)
    end

    local input_keys = "F"

    if curl_response_code and curl_response_code >= 200 and curl_response_code < 300 then
        input_keys = "S"
    end

    call_flow.find_child_node_with_dtmf_input(input_keys, node_data)
end

return M
